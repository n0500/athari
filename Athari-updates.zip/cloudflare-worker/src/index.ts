import { createRemoteJWKSet, jwtVerify } from "jose";

type Env = {
  AI: Ai;
  FIREBASE_PROJECT_ID: string;
  ALLOWED_ORIGINS: string;
};

const MODEL = "@cf/google/gemma-4-26b-a4b-it";
const MAX_FILES = 8;
const MAX_FILE_BYTES = 10 * 1024 * 1024;
const MAX_TOTAL_BYTES = 30 * 1024 * 1024;

type Analysis = {
  extractedFacts: Array<{ fact: string; support: string }>;
  suggestedClassifications: Array<{
    elementId: string;
    elementName: string;
    reason: string;
    requirementIds?: string[];
  }>;
  draftTitle: string;
  draftDescription: string;
  draftImpact: string;
  draftHighlight: string;
  missingInformation: null | { question: string; reason: string };
  warnings: string[];
  unreadableFiles?: string[];
};

type WorkerFrameworkElement = {
  id: string;
  officialName: string;
  description?: string;
  requirements?: Array<{ id: string; label: string }>;
};

function cors(origin: string) {
  return {
    "Access-Control-Allow-Origin": origin,
    "Access-Control-Allow-Headers": "authorization,content-type",
    "Access-Control-Allow-Methods": "POST,OPTIONS",
    Vary: "Origin",
  };
}

function allowedOrigin(request: Request, env: Env) {
  const origin = request.headers.get("Origin") || "";
  const allowed = env.ALLOWED_ORIGINS.split(",")
    .map((value) => value.trim())
    .filter(Boolean);
  return allowed.includes(origin) ? origin : allowed[0] || "";
}

async function verifyFirebaseToken(request: Request, env: Env) {
  const header = request.headers.get("Authorization") || "";
  if (!header.startsWith("Bearer ")) throw new Error("UNAUTHORIZED");

  const token = header.slice(7);
  const jwks = createRemoteJWKSet(
    new URL(
      "https://www.googleapis.com/service_accounts/v1/jwk/securetoken@system.gserviceaccount.com"
    )
  );

  const issuer = `https://securetoken.google.com/${env.FIREBASE_PROJECT_ID}`;
  const { payload } = await jwtVerify(token, jwks, {
    issuer,
    audience: env.FIREBASE_PROJECT_ID,
  });

  if (!payload.sub) throw new Error("UNAUTHORIZED");
  return payload.sub;
}

function stripCodeFence(text: string) {
  return text
    .trim()
    .replace(/^```(?:json)?\s*/i, "")
    .replace(/\s*```$/i, "")
    .trim();
}

function parseModelJson(value: unknown): unknown {
  if (typeof value === "string") {
    return JSON.parse(stripCodeFence(value));
  }

  if (!value || typeof value !== "object") {
    throw new Error("AI_INVALID_OUTPUT");
  }

  const object = value as Record<string, unknown>;

  if ("response" in object) {
    const response = object.response;
    if (typeof response === "string") {
      return JSON.parse(stripCodeFence(response));
    }
    if (response && typeof response === "object") return response;
  }

  const choices = object.choices;
  if (Array.isArray(choices) && choices.length) {
    const first = choices[0] as Record<string, unknown>;
    const message =
      first && typeof first.message === "object" && first.message
        ? (first.message as Record<string, unknown>)
        : undefined;
    const content = message?.content;
    if (typeof content === "string") {
      return JSON.parse(stripCodeFence(content));
    }
  }

  throw new Error("AI_INVALID_OUTPUT");
}

function asString(value: unknown) {
  return typeof value === "string" ? value.trim() : "";
}

function sanitizeAnalysis(
  value: unknown,
  framework: WorkerFrameworkElement[]
): Analysis {
  if (!value || typeof value !== "object") {
    throw new Error("AI_INVALID_OUTPUT");
  }

  const raw = value as Record<string, unknown>;
  const allowedById = new Map(framework.map((item) => [item.id, item]));
  const allowedByName = new Map(
    framework.map((item) => [item.officialName, item])
  );

  const extractedFacts = Array.isArray(raw.extractedFacts)
    ? raw.extractedFacts
        .slice(0, 30)
        .map((item) => {
          const fact =
            item && typeof item === "object"
              ? (item as Record<string, unknown>)
              : {};
          return {
            fact: asString(fact.fact),
            support: asString(fact.support),
          };
        })
        .filter((item) => item.fact)
    : [];

  const suggestedClassifications = Array.isArray(
    raw.suggestedClassifications
  )
    ? raw.suggestedClassifications
        .slice(0, 3)
        .map((item) => {
          const suggestion =
            item && typeof item === "object"
              ? (item as Record<string, unknown>)
              : {};

          const requestedId = asString(suggestion.elementId);
          const requestedName = asString(suggestion.elementName);
          const verified =
            allowedById.get(requestedId) || allowedByName.get(requestedName);

          if (!verified) return null;

          const allowedRequirementIds = new Set(
            (verified.requirements ?? []).map((requirement) => requirement.id)
          );
          const requirementIds = Array.isArray(suggestion.requirementIds)
            ? suggestion.requirementIds
                .map(asString)
                .filter((id) => allowedRequirementIds.has(id))
                .slice(0, allowedRequirementIds.size)
            : [];

          return {
            elementId: verified.id,
            elementName: verified.officialName,
            reason: asString(suggestion.reason),
            requirementIds,
          };
        })
        .filter(Boolean) as Analysis["suggestedClassifications"]
    : [];

  const missing =
    raw.missingInformation && typeof raw.missingInformation === "object"
      ? (raw.missingInformation as Record<string, unknown>)
      : null;
  const question = missing ? asString(missing.question) : "";

  return {
    extractedFacts,
    suggestedClassifications:
      framework.length > 0 ? suggestedClassifications : [],
    draftTitle: asString(raw.draftTitle),
    draftDescription: asString(raw.draftDescription),
    draftImpact: asString(raw.draftImpact),
    draftHighlight: asString(raw.draftHighlight),
    missingInformation: question
      ? { question, reason: asString(missing?.reason) }
      : null,
    warnings: Array.isArray(raw.warnings)
      ? raw.warnings.slice(0, 10).map(asString).filter(Boolean)
      : [],
  };
}

async function fileToMarkdown(file: File, env: Env) {
  const converted = await env.AI.toMarkdown(
    {
      name: file.name,
      blob: new Blob([await file.arrayBuffer()], {
        type: file.type || "application/octet-stream",
      }),
    },
    {
      conversionOptions: {
        output: { format: "markdown" },
        pdf: { metadata: false },
      },
    }
  );

  const result = Array.isArray(converted) ? converted[0] : converted;
  return result &&
    "data" in result &&
    typeof result.data === "string"
    ? result.data.trim()
    : "";
}

const MAX_INDICATOR_INPUT = 12000;

function cleanIndicatorLines(value: unknown) {
  const lines = asString(value)
    .split(/\n+/)
    .map((line) => line.replace(/^\s*(?:[•\-–*·◆]\s*|[0-9٠-٩]+[.)]\s*)/, "").trim())
    .filter((line) => line.length > 0 && line.length <= 200)
    .slice(0, 5);

  const kept: string[] = [];
  for (const line of lines) {
    const next = [...kept, line].join("\n");
    if (next.length > 700) break;
    kept.push(line);
  }
  return kept.join("\n");
}

/**
 * Suggests excellence indicators for an evidence item that was analysed
 * before indicators existed. It reads only text already stored with the
 * evidence (approved wording and extracted facts), so no file is re-read.
 */
async function handleIndicators(request: Request, env: Env, origin: string) {
  try {
    await verifyFirebaseToken(request, env);

    const body = (await request.json().catch(() => ({}))) as Record<string, unknown>;
    const facts = Array.isArray(body.facts) ? body.facts.map(asString).filter(Boolean).slice(0, 20) : [];
    const elements = Array.isArray(body.elements) ? body.elements.map(asString).filter(Boolean).slice(0, 5) : [];
    const source = [
      `العنوان: ${asString(body.title)}`,
      `وصف التنفيذ: ${asString(body.description)}`,
      `الأثر: ${asString(body.impact)}`,
      elements.length ? `عناصر التقييم: ${elements.join("، ")}` : "",
      facts.length ? `حقائق مستخرجة من الشاهد:\n- ${facts.join("\n- ")}` : "",
    ]
      .filter(Boolean)
      .join("\n")
      .slice(0, MAX_INDICATOR_INPUT);

    if (!asString(body.title) && !asString(body.description) && !facts.length) {
      return Response.json({ error: "EVIDENCE_TEXT_REQUIRED" }, { status: 400, headers: cors(origin) });
    }

    const prompt = `
You write "excellence indicators" (مؤشرات التميّز) for ONE teacher evidence item, using ONLY the text below.

RULES:
- Up to 5 lines, one indicator per line, each at most 20 words, formal Modern Standard Arabic.
- Each line shows why the work goes beyond the basic requirement, chosen only from what the text documents: innovation (a first or new practice), reach (beyond her own class: department, school, parents, community), documented measurable result, or sustainability/transfer (repeated practice, shared with colleagues).
- Never invent firsts, numbers, dates, results, participants or places. No generic praise. Do not restate the title.
- If the text does not support any indicator, return an empty string.
- Return JSON only: {"indicators":"line1\nline2"}

EVIDENCE TEXT:
${source}
`;

    const aiResult = await env.AI.run(MODEL, {
      messages: [
        { role: "system", content: "Return one valid JSON object only. Evidence-grounded. Never fabricate." },
        { role: "user", content: prompt },
      ],
      temperature: 0.1,
      max_completion_tokens: 600,
      chat_template_kwargs: { enable_thinking: false },
    });

    const parsed = parseModelJson(aiResult);
    const raw = parsed && typeof parsed === "object" ? (parsed as Record<string, unknown>) : {};

    return Response.json(
      { indicators: cleanIndicatorLines(raw.indicators) },
      { headers: { ...cors(origin), "Cache-Control": "no-store" } }
    );
  } catch (error) {
    const message = error instanceof Error ? error.message : "UNKNOWN_ERROR";
    const status = message === "UNAUTHORIZED" ? 401 : /quota|limit|too many|429/i.test(message) ? 429 : 500;
    return Response.json({ error: message }, { status, headers: cors(origin) });
  }
}

export default {
  async fetch(request: Request, env: Env): Promise<Response> {
    const origin = allowedOrigin(request, env);

    if (request.method === "OPTIONS") {
      return new Response(null, { headers: cors(origin) });
    }

    const url = new URL(request.url);
    if (request.method === "POST" && url.pathname === "/indicators") {
      return handleIndicators(request, env, origin);
    }
    if (request.method !== "POST" || url.pathname !== "/analyze") {
      return Response.json(
        { error: "NOT_FOUND" },
        { status: 404, headers: cors(origin) }
      );
    }

    try {
      await verifyFirebaseToken(request, env);

      const form = await request.formData();
      const multi = form
        .getAll("files")
        .filter((value): value is File => value instanceof File);
      const legacy = form.get("file");
      const files = multi.length
        ? multi
        : legacy instanceof File
        ? [legacy]
        : [];
      const frameworkText = String(form.get("framework") || "[]");

      if (!files.length) {
        return Response.json(
          { error: "FILE_REQUIRED" },
          { status: 400, headers: cors(origin) }
        );
      }

      if (files.length > MAX_FILES) {
        return Response.json(
          { error: "TOO_MANY_FILES" },
          { status: 413, headers: cors(origin) }
        );
      }

      const totalBytes = files.reduce((sum, file) => sum + file.size, 0);
      if (
        totalBytes > MAX_TOTAL_BYTES ||
        files.some((file) => file.size > MAX_FILE_BYTES)
      ) {
        return Response.json(
          { error: "FILE_TOO_LARGE" },
          { status: 413, headers: cors(origin) }
        );
      }

      let framework: WorkerFrameworkElement[] = [];

      try {
        const parsed = JSON.parse(frameworkText);
        if (Array.isArray(parsed)) {
          framework = parsed
            .slice(0, 30)
            .map((item) => {
              const data =
                item && typeof item === "object"
                  ? (item as Record<string, unknown>)
                  : {};
              const requirements = Array.isArray(data.requirements)
                ? data.requirements
                    .slice(0, 30)
                    .map((requirement) => {
                      const value =
                        requirement && typeof requirement === "object"
                          ? (requirement as Record<string, unknown>)
                          : {};
                      return {
                        id: asString(value.id),
                        label: asString(value.label),
                      };
                    })
                    .filter((requirement) => requirement.id && requirement.label)
                : [];
              return {
                id: asString(data.id),
                officialName: asString(data.officialName),
                description: asString(data.description),
                requirements,
              };
            })
            .filter((item) => item.id && item.officialName);
        }
      } catch {
        framework = [];
      }

      const parts: string[] = [];
      const unreadableFiles: string[] = [];

      for (let index = 0; index < files.length; index += 1) {
        const file = files[index];
        try {
          const text = await fileToMarkdown(file, env);
          if (text) {
            parts.push(
              `=== الملف ${index + 1}: ${file.name} ===\n${text}`
            );
          } else {
            unreadableFiles.push(file.name);
          }
        } catch {
          unreadableFiles.push(file.name);
        }
      }

      if (!parts.length) {
        return Response.json(
          { error: "DOCUMENT_COULD_NOT_BE_READ" },
          { status: 422, headers: cors(origin) }
        );
      }

      const evidence = parts.join("\n\n").slice(0, 120000);
      const prompt = `
You are Athari, an evidence-grounded assistant for teachers.

The teacher uploaded ${files.length} attachment(s) together as ONE evidence item. Analyze the attachments jointly as one evidence package. A fact may be supported by one attachment or by several attachments, but never invent a relationship that is not shown in the evidence.

NON-NEGOTIABLE RULES:
- Never invent results, impact, dates, counts, people, organizations, percentages, or achievements.
- Extract only facts directly supported by the supplied evidence.
- "support" must identify the supporting attachment using a short Arabic label and, when useful, the original file name.
- Use only performance elements in VERIFIED_FRAMEWORK.
- If VERIFIED_FRAMEWORK is empty, suggestedClassifications must be [].
- Suggest up to THREE classification elements only when each one is directly supported by the evidence.
- Order suggestedClassifications from strongest evidence match to weakest supported match. The first suggestion is the recommended primary classification.
- Each classification reason must independently explain the exact evidence that supports that element.
- Do not add a classification merely because it is thematically related.
- Each element may contain a list of mandatory requirements. For every suggested classification, return requirementIds only for mandatory requirements that this evidence DIRECTLY documents.
- Never mark a mandatory requirement merely because it usually accompanies the activity or because the element is related. If the evidence does not prove it, omit its id.
- requirementIds are suggestions for teacher confirmation, not an automatic score or final decision.
- draftImpact must contain only impact directly supported by evidence.
- If no impact is documented, write exactly: "لا يوجد أثر موثق متاح حاليًا."
- draftHighlight lists up to 5 "excellence indicators" (مؤشرات التميّز), one per line separated by "\n", each at most 20 words, formal Arabic. Each line shows why the work goes beyond the basic requirement, choosing only from what the evidence documents: innovation (a first or new practice), reach (beyond her own class: department, school, parents, community), documented measurable result, or sustainability/transfer (repeated practice, shared with colleagues). Never invent firsts, numbers, dates, results or participants; no generic praise. Return fewer lines, or an empty string, when the evidence does not support them.
- Ask at most ONE essential missing-information question.
- Never score or rate the teacher.
- Return JSON only, with no Markdown fence and no commentary.

ARABIC OUTPUT RULES:
- All user-facing generated text must be in clear Modern Standard Arabic, even when the evidence is in English.
- Keep official performance element names exactly as they appear in VERIFIED_FRAMEWORK.
- Proper nouns, organization names, product names, and original document titles may remain in their original language only when needed for accuracy.
- Do not copy long English sentences into user-facing fields; summarize them faithfully in Arabic.

Required JSON shape:
{
  "extractedFacts":[{"fact":"","support":""}],
  "suggestedClassifications":[{"elementId":"","elementName":"","reason":"","requirementIds":[]}],
  "draftTitle":"",
  "draftDescription":"",
  "draftImpact":"",
  "draftHighlight":"",
  "missingInformation":null,
  "warnings":[]
}

VERIFIED_FRAMEWORK:
${JSON.stringify(framework)}

EVIDENCE PACKAGE:
${evidence}
`;

      const aiResult = await env.AI.run(MODEL, {
        messages: [
          {
            role: "system",
            content:
              "Return one valid JSON object only. Evidence-grounded. Never fabricate. Treat all supplied attachments as one evidence package and write user-facing text in clear Modern Standard Arabic.",
          },
          { role: "user", content: prompt },
        ],
        temperature: 0.1,
        max_completion_tokens: 1800,
        chat_template_kwargs: { enable_thinking: false },
      });

      const parsed = parseModelJson(aiResult);
      const safe = sanitizeAnalysis(parsed, framework);
      const conversionWarnings = unreadableFiles.map(
        (name) => `تعذر قراءة الملف «${name}» ضمن هذه المحاولة.`
      );

      return Response.json(
        {
          ...safe,
          unreadableFiles,
          warnings: [...safe.warnings, ...conversionWarnings].slice(0, 10),
        },
        {
          headers: {
            ...cors(origin),
            "Cache-Control": "no-store",
          },
        }
      );
    } catch (error) {
      const message =
        error instanceof Error ? error.message : "UNKNOWN_ERROR";
      const status =
        message === "UNAUTHORIZED"
          ? 401
          : /quota|limit|too many|429/i.test(message)
          ? 429
          : 500;

      return Response.json(
        { error: message },
        { status, headers: cors(origin) }
      );
    }
  },
};
